# 🌿 Flora of SXC

A responsive botanical directory website documenting the trees growing across the **St. Xavier's College** campus — built for the Department of Botany. Each tree has a dedicated profile page with botanical classification, ecology, uses, and an auto-generated **QR code** that can be printed and placed near the actual tree on campus, so anyone scanning it opens that tree's page instantly.

---

## ✅ Currently Completed Features

### Public site
- **Home page (`index.html`)**
  - Animated hero section (falling leaf particles, staggered title reveal, animated CTA buttons)
  - Animated stat counters (species / families / QR tags documented)
  - "About the project" section
  - Featured Trees grid pulled live from the data table
  - "How the Campus QR Trail Works" 4-step explainer section
  - CTA banner linking to the admin panel
- **Tree Directory (`trees.html`)**
  - Live search (by common name, local name, botanical name, family)
  - Filter by botanical family and by plant type (Tree / Palm / Shrub / Climber)
  - Responsive card grid with images, botanical name, and family
- **Tree Profile page (`tree.html?id=<tree_id>`)**
  - Full botanical classification (common/local/botanical name, family, genus, plant type)
  - Growth & ecology info (height, leaf type, flowering season, native region, campus location)
  - Description and Uses & Significance sections
  - **Auto-generated QR code** for that exact tree's URL, with a "Download QR Code" button (PNG) — ready to print and mount on campus
  - Friendly "Tree Not Found" state for bad/outdated links
- **Global**
  - Fully responsive layout (desktop, tablet, mobile) with a slide-in mobile nav
  - Smooth scroll-reveal animations, hover/scale transitions on cards and buttons, animated page-load overlay and first-visit loader
  - Shared header/footer injected via `js/main.js` so every page stays in sync

### Admin panel (`admin.html`)
- **Google Sign-In gate** — only Gmail accounts listed in `js/admin-config.js` (`ADMIN_CONFIG.allowedAdmins`) are shown the management dashboard after signing in with a real Google account (via Google Identity Services). Anyone else who signs in sees an "unauthorised account" message and no admin tools.
- Once signed in as an approved admin:
  - **Add** a new tree (full form: names, family, genus, type, height, leaf type, flowering season, native region, campus location, image URL, description, uses, "feature on home page" toggle)
  - **Edit** any existing tree record
  - **Delete** a tree record (with confirmation)
  - **Generate & download a QR code** for any tree directly from the tree list, without leaving the dashboard
- Session persists for 8 hours per browser tab (via `sessionStorage`), then requires signing in again

---

## ⚠️ Important — Please Read Before Going Live

### 1. You must finish the Google Sign-In setup
`js/admin-config.js` currently contains **placeholder values**:
```js
googleClientId: 'YOUR_GOOGLE_OAUTH_CLIENT_ID.apps.googleusercontent.com',
allowedAdmins: ['youradmin@gmail.com']
```
To activate real admin login:
1. Go to the [Google Cloud Console](https://console.cloud.google.com/) → **APIs & Services → Credentials → Create Credentials → OAuth Client ID** → Application type **Web application**.
2. Add your live site URL (and `http://localhost` if testing) under **Authorized JavaScript origins**.
3. Copy the generated **Client ID** into `googleClientId` in `js/admin-config.js`.
4. List every Gmail address that should have admin rights inside `allowedAdmins`.

Until this is done, the login card will show a warning instead of a working Google button.

### 2. Real security limits of a static site (please read carefully)
This project is a **static website with no server-side backend**. The Google Sign-In gate is genuine — it confirms the visitor's real Gmail identity via Google's own servers — but it can only control **what the browser shows**. It cannot stop a technically savvy visitor from calling the underlying data-table API endpoints directly, because those endpoints are not protected by a server-side login check. In other words:
- ✅ Regular visitors browsing normally will only ever see the public pages — the "Admin" tools are invisible to them.
- ✅ Only approved Gmail accounts can open and use the dashboard UI to add/edit/delete trees.
- ⚠️ This is **not** equivalent to a real backend authorization system. Do not store sensitive/private information in this table, and treat this as "who is allowed to use the UI," not "who can technically write to the database."

I also checked this project's **platform-level Hosted route-access rules** (the feature that can gate entire pages/paths at the server before they ever reach the browser). That feature **requires an active Plus (or higher) membership** on this workspace, and the current plan doesn't have it — so I was not able to add a true server-enforced login wall in front of `admin.html`. If you upgrade the workspace membership, let me know and I can configure real server-side route protection (e.g., only authenticated/allow-listed emails can even load `admin.html` or its API paths) in addition to the in-app Google Sign-In gate already built.

### 3. QR Codes
QR codes are generated **client-side** (via the `qrcodejs` library) on both the public tree page and the admin dashboard. Each QR encodes the exact canonical URL `tree.html?id=<tree_id>` for that tree. Download the PNG from either page and print it for mounting near the tree on campus.

---

## 🔗 Functional Entry Points (Pages & Parameters)

| Path | Description |
|---|---|
| `/index.html` | Home page — hero, stats, featured trees, QR explainer, CTA |
| `/trees.html` | Full tree directory with search + filters |
| `/tree.html?id={tree_id}` | Individual tree profile + QR code (this is the URL encoded in every printed QR tag) |
| `/admin.html` | Faculty admin login + dashboard (Add / Edit / Delete trees, generate QR) |

---

## 🧬 Data Model — `trees` table

| Field | Type | Purpose |
|---|---|---|
| `id` | text | Unique identifier, used in the QR / profile URL |
| `common_name` | text | Common English name |
| `local_name` | text | Local/regional name |
| `botanical_name` | text | Scientific name (italicized in UI) |
| `family` | text | Botanical family |
| `genus` | text | Genus |
| `plant_type` | text (enum) | Tree / Palm / Shrub / Climber |
| `description` | rich_text | Full description |
| `height` | text | Typical height range |
| `leaf_type` | text | Leaf description |
| `flowering_season` | text | Flowering/fruiting period |
| `uses` | rich_text | Medicinal / ecological / cultural uses |
| `native_region` | text | Native range |
| `campus_location` | text | Where it stands on campus |
| `image_url` | text | Photograph URL |
| `featured` | bool | Shown in the Home page "Featured" grid |
| `added_by` | text | Email of the admin who created/edited it |

Data is stored via the built-in RESTful Table API (`tables/trees`). The preview editor and the live hosted deployment use **separate data stores** — rows added in the editor's preview will not automatically appear on a hosted/deployed site's live database, and vice versa. Ask me to copy seed data into the live database after a Hosted Deploy if needed.

8 sample trees (Banyan, Peepal, Neem, Gulmohar, Mango, Ashoka/Polyalthia, Amaltas, Coconut Palm) are pre-loaded as a starting point — edit/replace them from the admin dashboard once Google Sign-In is configured.

---

## 🚧 Not Yet Implemented / Suggested Next Steps

1. **Finish Google OAuth setup** (see section above) — required before the admin dashboard can be used for real.
2. **Server-side route protection for `/admin.html`** — available once this workspace has a Plus (or higher) membership; I can wire this up on request.
3. **Bulk QR sheet export** — currently each QR is downloaded one at a time; a "download all as a printable sheet" option could be added.
4. **Image uploads** — currently tree photos are added via an image URL field; there's no built-in file-upload/storage for photos (static sites can't run their own upload backend). You can host images anywhere reachable by a public URL and paste that into the "Image URL" field.
5. **Multi-language support** for local plant names, if useful for your region.
6. **Map view** showing all trees plotted on a campus map, linking each pin to its profile page.

---

## 🛠️ Tech Stack

- Semantic **HTML5** + custom **CSS3** (CSS variables, animations, responsive grid/flex)
- Vanilla **JavaScript** (no framework) — `js/main.js`, `js/api.js`, `js/trees-directory.js`, `js/tree-detail.js`, `js/admin.js`, `js/admin-config.js`
- **Google Identity Services** for real Gmail sign-in verification
- **qrcodejs** (CDN) for client-side QR code generation
- **Font Awesome** for icons, **Google Fonts** (Inter + Poppins)
- Data persistence via the built-in RESTful Table API (`tables/trees`)

## 🚀 Deployment

To publish this site, use the **Publish tab** — it will handle deployment and give you the live URL. If you'd like me to run a Hosted Deploy directly (creating the live D1 database from the `trees` table schema and seeding it), just ask.
