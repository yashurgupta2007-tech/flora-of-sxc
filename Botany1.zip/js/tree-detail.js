document.addEventListener("DOMContentLoaded", async () => {
    const content = document.getElementById("tree-content");

    if (!content) {
        console.error("Tree detail: #tree-content not found.");
        return;
    }

    const params = new URLSearchParams(window.location.search);
    const id = params.get("id");

    console.log("Tree profile URL:", window.location.href);
    console.log("Tree ID from URL:", id);

    if (!id) {
        renderNotFound();
        return;
    }

    try {
        const tree = await fetchTreeById(id);

        if (!tree || tree.is_active === false) {
            renderNotFound();
            return;
        }

        renderTree(tree);
    } catch (error) {
        console.error("Could not load tree:", error);
        renderNotFound();
    }

    function renderNotFound() {
        content.innerHTML = `
    <div class="not-found" style="padding-top:160px;">
        <div class="big-icon">
        <i class="fa-solid fa-seedling"></i>
        </div>

        <h2>Tree Not Found</h2>

        <p style="color:var(--ink-600); max-width:420px;">
        This QR code or link might be outdated, or the tree
        entry was removed. Browse the full directory instead.
        </p>

        <a href="trees.html"
        class="btn btn-primary"
        style="margin-top:20px;">
        <i class="fa-solid fa-arrow-left"></i>
        Back to Directory
        </a>
    </div>
    `;
    }

    function hasValue(value) {
        return value !== null &&
            value !== undefined &&
            String(value).trim() !== "";
    }

    function row(label, value) {
        if (!hasValue(value)) return "";

        return `
    <li>
        <span class="label">${escapeHTML(label)}</span>
        <span class="value">${escapeHTML(String(value))}</span>
    </li>
    `;
    }

    function section(title, icon, value) {
        if (!hasValue(value)) return "";

        return `
    <div class="detail-card">
        <h3>
        <i class="fa-solid ${icon}"></i>
        ${escapeHTML(title)}
        </h3>

        <p>${escapeHTML(String(value))}</p>
    </div>
    `;
    }

    function renderTree(tree) {
        document.title = `${tree.common_name || "Tree"} | Flora of SXC`;

        const image = hasValue(tree.image_url)
            ? tree.image_url
            : "https://placehold.co/1200x600?text=Flora+of+SXC";

        const canonicalUrl =
            window.location.origin +
            window.location.pathname +
            "?id=" +
            encodeURIComponent(tree.id);

        const zoneName = tree.campus_zones?.name;

        content.innerHTML = `


    <section class="tree-detail-hero">
        <img
        src="${escapeHTML(image)}"
        alt="${escapeHTML(tree.common_name || "Tree or plant")}"
        >

        <div class="hero-caption">
        <h1>
            ${escapeHTML(tree.common_name || "Unnamed Plant")}
        </h1>

        ${hasValue(tree.botanical_name)
                ? `<div class="sci-name">
                ${escapeHTML(tree.botanical_name)}
                </div>`
                : ""
            }
        </div>
    </section>



    <div class="detail-grid">


        <div class="reveal">

        ${section(
                "Reason for Common Name",
                "fa-book-open",
                tree.reason_common_name
            )}

        ${section(
                "Scientific Name & Meaning",
                "fa-dna",
                tree.scientific_name_meaning
            )}

        ${section(
                "Morphology",
                "fa-leaf",
                tree.morphology
            )}

        ${section(
                "Reason Behind Morphology",
                "fa-magnifying-glass",
                tree.morphology_reason
            )}

        ${section(
                "Traditional Uses",
                "fa-hand-holding-heart",
                tree.traditional_uses
            )}

        ${section(
                "Interesting Facts",
                "fa-lightbulb",
                tree.interesting_facts
            )}

        ${section(
                "Story Behind the Tree",
                "fa-book",
                tree.story
            )}

        </div>

        

        <div class="reveal">

        

        <div class="detail-card">
            <h3>
            <i class="fa-solid fa-seedling"></i>
            Plant Information
            </h3>

            <ul class="info-list">
            ${row("Common Name", tree.common_name)}
            ${row("Scientific Name", tree.botanical_name)}
            ${row("Plant Type", tree.plant_type)}
            ${row("Campus Location", zoneName)}
            </ul>
        </div>

        <div class="detail-card qr-box">
            <h3 style="justify-content:center;">
            <i class="fa-solid fa-qrcode"></i>
            Scan This Tree
            </h3>

            <div id="qrcode-container"></div>

            <p class="hint">
            Scanning this code opens the permanent
            Flora of SXC profile for this tree.
            </p>

            <button
            class="btn btn-dark"
            id="download-qr-btn"
            style="width:100%; justify-content:center;"
            >
            <i class="fa-solid fa-download"></i>
            Download QR Code
            </button>
        </div>

        </div>
    </div>
    `;


        const qrContainer = document.getElementById("qrcode-container");

        if (qrContainer && window.QRCode) {
            new QRCode(qrContainer, {
                text: canonicalUrl,
                width: 180,
                height: 180,
                colorDark: "#0f3d24",
                colorLight: "#ffffff",
                correctLevel: QRCode.CorrectLevel.H
            });
        } else {
            console.warn("QR Code library is not loaded.");
        }


        const downloadBtn = document.getElementById("download-qr-btn");

        if (downloadBtn) {
            downloadBtn.addEventListener("click", () => {
                const canvas = qrContainer?.querySelector("canvas");

                if (!canvas) return;

                const safeName = (tree.common_name || "tree")
                    .replace(/[^a-z0-9]+/gi, "-")
                    .replace(/^-|-$/g, "");

                const link = document.createElement("a");
                link.download = `QR-${safeName}.png`;
                link.href = canvas.toDataURL("image/png");
                link.click();
            });
        }
    }
});